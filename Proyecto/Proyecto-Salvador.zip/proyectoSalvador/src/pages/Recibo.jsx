import  Recibos  from "../components/Recibos";
const Recibo = () => {
    return (
      <main role="main">
      <section>
          <div className="bannerCarrito">
            <h1>RECIBOS</h1>
          </div>
      </section>
        <section>
          <Recibos />
        </section>
      </main>
    );
  };
  
  export default Recibo;
  