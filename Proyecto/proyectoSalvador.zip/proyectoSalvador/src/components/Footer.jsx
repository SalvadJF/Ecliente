const Footer = () => {
  return (
    <footer role="contentinfo">
      <div>
        <h2 className="imagenCorporativa">TTT</h2>
      </div>
      <div>
        <p className="titulos">@copyrigth Tres Tecnicas Tridimensionales </p>
        <p className="titulos">TTT@corp.com</p>
      </div>
    </footer>
  );
};

export default Footer;
